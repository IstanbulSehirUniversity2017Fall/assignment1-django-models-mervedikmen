from django.apps import AppConfig


class AppmerveConfig(AppConfig):
    name = 'appmerve'
